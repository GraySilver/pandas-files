from pandasfiles.base.setting import Setting




class Distribution(Setting):
        pass


