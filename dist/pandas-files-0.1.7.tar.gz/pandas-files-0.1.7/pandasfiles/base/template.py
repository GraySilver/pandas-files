# -*-coding:utf-8-*-


STORE_NAME = '/{}[{}].h5'

PARTITION_VARIABLE= "PART{}"

FILE_KEYS_LIST = 'FILE_KEYS{}'

INDEX_FILE = '/{}.json'